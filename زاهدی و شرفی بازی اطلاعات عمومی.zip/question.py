import tkinter as tk
from random import shuffle

class QuestionGame:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("بازی اطلاعات عمومی")
        self.root.configure(background="skyblue")  
        self.questions = [
            {"question": "تابلوی لبخند ژکوند اثر کیست؟", "answers": ["ونگوک", "داوینچی", "پیکاسو", "رامبراند"], "correct": 1},
            {"question": "کدام درخت نماد صلح است؟", "answers": ["سرو", "سیب", "زیتون", "نارنج"], "correct": 2},
            {"question": "تجزیه ظروف پلاستیکی چند سال طول میکشد؟", "answers": ["50سال", "5 هزار سال", "50هزار سال", "500سال"], "correct": 3},
            {"question": "جزایر لانگرهانس در کجا قرار دارد؟", "answers": ["اقیانوسیه", "لوز المعده", "اسپانیا", "جمجمه"], "correct": 1},
            {"question": " پاریس کوچولو لقب کدام شهر ایران است؟", "answers": ["بروجرد", "شیراز", "اصفهان", "تبریز"], "correct": 0},
            {"question": "کدام حشره بیشترین طول عمر را دارد؟", "answers": ["ملخ", "موریانه", "مورچه", "عنکبوت"], "correct": 1},
            {"question": "کدام حیوان در هنگام خواب یک چشم خود را باز نگه میدارد؟", "answers": ["شغال", "جغد", "روباه", "گرگ"], "correct": 3},
            {"question": " کدام کشور سه زبان رسمی دارد؟", "answers": ["بلژیک", "سنگاپور ", "سوییس", "کانادا"], "correct": 0},
            {"question": "کوچک ترین سوره قرآن چه نام دارد؟", "answers": ["بقره", "ناس", "کوثر", "توحید"], "correct": 2},
            {"question": " حق قرار داد رویتر چند سال بود؟", "answers": ["10سال", "15سال", "25سال", "20سال"], "correct":2},
        ]
        shuffle(self.questions)
        self.current_question = 0
        self.score = 0
        self.create_widgets()

    def create_widgets(self):
        self.question_label = tk.Label(self.root, text=f"سوال {self.current_question + 1}/10: {self.questions[self.current_question]['question']}", wraplength=400, font=("Arial", 16), fg="black", bg="skyblue")  
        self.question_label.pack(pady=20)  

        self.answer_buttons = []
        for i, answer in enumerate(self.questions[self.current_question]["answers"]):
            button = tk.Button(self.root, text=answer, command=lambda i=i: self.check_answer(i), font=("Arial", 14), fg="#00698f", bg="white")  
            button.pack(pady=5) 
            self.answer_buttons.append(button)

        self.score_label = tk.Label(self.root, text=f"امتیاز: {self.score}", font=("Arial", 16), fg="#00698f", bg="white")  
        self.score_label.pack(pady=20) 

        button_frame = tk.Frame(self.root, bg="skyblue") 
        self.next_button = tk.Button(button_frame, text="بعدی", command=self.next_question, font=("Arial", 14), fg="black", bg="white")  
        self.next_button.pack(side=tk.RIGHT, padx=5)  

        self.previous_button = tk.Button(button_frame, text="قبلی", command=self.previous_question, font=("Arial", 14), fg="black", bg="white")  
        self.previous_button.pack(side=tk.LEFT, padx=5) 
        button_frame.pack(pady=20)  

        self.provide= tk.Label(self.root, text=f"Provide by:Fatemeh Zahedi & Zahra Sharafifard ", font=("Arial", 16), fg="#00698f", bg="white")  
        self.provide.pack(pady=100) 

    def check_answer(self, answer):
        if answer == self.questions[self.current_question]["correct"]:
            self.score += 5
            self.score_label.config(text=f"امتیاز: {self.score}")
        self.next_question()

    def next_question(self):
        self.current_question += 1
        if self.current_question == len(self.questions):
            self.game_over()
        else:
            self.question_label.config(text=f"سوال {self.current_question + 1}/10: {self.questions[self.current_question]['question']}")
            for i, button in enumerate(self.answer_buttons):
                button.config(text=self.questions[self.current_question]["answers"][i], command=lambda i=i: self.check_answer(i))

    def previous_question(self):
        if self.current_question > 0:
            self.current_question -= 1
            self.question_label.config(text=f"سوال {self.current_question + 1}/10: {self.questions[self.current_question]['question']}")
            for i, button in enumerate(self.answer_buttons):
                button.config(text=self.questions[self.current_question]["answers"][i], command=lambda i=i: self.check_answer(i))

    def game_over(self):
        self.question_label.config(text="!بازی تمام شد")
        self.score_label.config(text=f"امتیاز نهایی: {self.score}")
        self.next_button.pack_forget()
        self.previous_button.pack_forget()
        for button in self.answer_buttons:
            button.pack_forget()

    def run(self):
       
        self.root.mainloop()

if __name__ == "__main__":
    game = QuestionGame()
    game.run()


    #فاطمه زاهدی 
    #زهرا شرفی فرد